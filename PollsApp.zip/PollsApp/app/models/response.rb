class Response < ApplicationRecord
    belongs_to(:answer_choice,
        class_name: "AnswerChoice",
        foreign_key: :answer_choice_id,
        primary_key: :id
    )

    belongs_to(:respondent,
        class_name: "User",
        foreign_key: :respondent_id,
        primary_key: :id
    )
   
    has_one(:question,
        through: :answer_choice,
        source: :question
      )

      validate :not_duplicate_response
      validate :respondent_is_not_poll_author
    
      def sibling_responses
        self.question.responses.where.not(id: self.id)
      end

      def respondent_already_answered?
        sibling_responses.exists?(respondent_id: self.respondent_id)
      end

      private

      def not_duplicate_response
        if respondent_already_answered?
            errors[:respondent_id] << "Cannot vote twice"
        end
      end

      def respondent_is_not_poll_author
        poll = self.question.poll.author_id
        if self.respondent_id == poll
            errors[:respondent_id] << "Can't reply to your own poll"
        end
      end
end