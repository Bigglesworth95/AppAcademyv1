class Question < ApplicationRecord
    validates :title, presence: true
    has_many(:answer_choices,
        class_name: "AnswerChoice",
        foreign_key: :question_id,
        primary_key: :id
    )    

    belongs_to(:poll, 
        class_name: "Poll",
        foreign_key: :poll_id,
        primary_key: :id
    )

    has_many(:responses,
        through: :answer_choices,
        source: :responses
    )

    def results_np1
        choices = self.answer_choices
        result_hash = {}
        choices.each do |choice|
            result_hash[choice.text] = choice.responses.count
        end
        result_hash
    end

    def results
        results = {}
        self.answer_choices.includes(:responses).each do |ac|
            results[ac.text] = ac.responses.length
        end
        results
        #first find answer choices
        #second, preload responses to all choices
        #third, for each response, make a k-v pair in the hash
    end

    def results_sql
        acs = AnswerChoice.find_by_sql([<<-SQL, id])
            SELECT 
                answer_choices.text, COUNT(responses.id) AS num_responses
            FROM
                answer_choices
            LEFT OUTER JOIN
                responses
            ON
                answer_choices.id = responses.answer_choice_id
            WHERE
                answer_choices.question_id = ?
            GROUP BY 
                answer_choices.id
            
        SQL
        #how do you know what to count & what join to do? 
        acs.inject({}) do |results, ac|
            results[ac.text] = ac.num_responses; results
        end
    end
end