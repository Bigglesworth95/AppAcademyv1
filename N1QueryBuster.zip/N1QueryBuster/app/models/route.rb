class Route < ApplicationRecord
  has_many :buses,
    class_name: 'Bus',
    foreign_key: :route_id,
    primary_key: :id

  def n_plus_one_drivers
    buses = self.buses

    all_drivers = {}
    buses.each do |bus|
      drivers = []
      bus.drivers.each do |driver|
        drivers << driver.name
      end
      all_drivers[bus.id] = drivers
    end

    all_drivers
  end

  def better_drivers_query
    #Create a hash with bus id's as keys and an array 
    #of bus drivers as the corresponding value.
    routes = self
      .buses
      .joins(:drivers)
      .select("buses.id as bus, drivers.*")
    buses_and_drivers = Hash.new
    routes.each do |route|
      buses_and_drivers[route.bus] = [route.drivers]
    end
    buses_and_drivers
  end

  def better_drivers_query2
    busses = self.buses.includes(:drivers)

    all_drivers = {}

    busses.each do |bus|
      drivers = []
      bus.drivers.each do |driver|
        drivers << driver.name
      end
      all_drivers[bus.id] = drivers
    end
    all_drivers 
  end
end
