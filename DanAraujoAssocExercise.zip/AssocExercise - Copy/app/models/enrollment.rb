class Enrollment < ApplicationRecord
    #need associations for user and course
    #After you are done adding the associations, you should be 
    #able to execute Enrollment.first.user 
    #and Enrollment.first.course

    # has_many(
    #     :people, 
    #     class_name: :Person,
    #     foreign_key: :house_id,
    #     primary_key: :id
    # )

    belongs_to(
        :students,
        class_name: 'User',
        foreign_key: :student_id,
        primary_key: :id
    )

    belongs_to(
        :courses,
        class_name: 'Course',
        foreign_key: :course_id,
        primary_key: :id
    )
end
