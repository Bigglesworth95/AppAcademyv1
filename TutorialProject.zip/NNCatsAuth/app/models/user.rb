require 'bcrypt'
class User < ApplicationRecord
    validates :username, presence: true, uniqueness: true
    validates :password_digest, presence: true
    validates :session_token, presence: true

    has_many :cats
    has_many :cat_rental_requests

    def reset_session_token!
        self.session_token = SecureRandom::urlsafe_base64(16)
    end

    def password=(password)
        self.password_digest = BCrypt::Password.create(password)
    end

    def is_password?(password)
        BCrypt::Password.new(self.password_digest).is_password?(password)
    end

    def find_by_credentials(username, password)
        user = User.find_by(username: username)
        if user == User.find_by(password_digest: BCrypt::Password.new(password))
            return user
        else
            return nil
        end
    end

end