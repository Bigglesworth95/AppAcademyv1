class SessionsController < ApplicationController
    before_action redirect_to cats_url if current_user
    def new
        render :new
    end

    def create
        user = User.find_by_credentials(
            params[:user][:username]
            params[:user][:password]
        )

        if user.nil? 
            flash.now[:errors] = ["Incorrect username/password"]
        else
            session[:session_token]=user.reset_session_token!
            fail
            redirect_to cats_url
        end
    end

    def destroy
        logout_user!
    end
end