# Easy Form Demo

* [app/models/cat.rb][cat]
* [app/controllers/cats_controller.rb][cats_controller]
* [app/views/cats/show.html.erb][cats/show]
* [app/views/cats/new.html.erb][cats/new]

[cat]: ./app/models/cat.rb
[cats_controller]: ./app/controllers/cats_controller.rb
[cats/show]: ./app/views/cats/index.html.erb
[cats/new]: ./app/views/cats/new.html
