# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)

patches = Cat.create!(birth_date:DateTime.new(2005, 11, 8), color: "white", name: "Patches", sex: "F", description: "cute")
carter = Cat.create!(birth_date: DateTime.new(2022, 8, 16), color: "black", name: "Carter", sex: "M", description: "Fat")

p_rr = CatRentalRequest.create!(cat_id: patches.id, start_date: DateTime.new(2022, 8, 16), end_date: DateTime.new(2022, 8, 20), status: "APPROVED")
c_rr = CatRentalRequest.create!(cat_id: carter.id, start_date: DateTime.new(2022, 8, 18), end_date: DateTime.new(2022, 8, 22), status: "PENDING")
p_rr2 = CatRentalRequest.create!(cat_id: patches.id, start_date: DateTime.new(2022, 11, 08), end_date: DateTime.new(2022, 11, 10), status: "APPROVED")