require 'date'
require 'action_view'
class Cat < ApplicationRecord
    include ActionView::Helpers::DateHelper
    CAT_COLORS = %w(black white orange brown).freeze
    #validates :color#, presence: true
    #validates :birth_date#, presence: true
    #validates :name#, presence: true
    #validates :sex#, presence: true
    #validates :color#, inclusion: CAT_COLORS
    def age
        p Time.now
        time_ago_in_words(self.birth_date)
    end

    has_many :cat_rental_requests, 
    class_name: "CatRentalRequest", 
    dependent: :destroy
end