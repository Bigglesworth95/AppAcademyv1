class CatRentalRequest < ApplicationRecord
    STATUS_STATES = %w(PENDING APPROVED DENIED).freeze
    #validates :status, inclusion: STATUS_STATES
    #validate :does_not_overlap_approved_request

    belongs_to :cat

    def approve!
        raise 'not pending' unless self.status == 'PENDING'
        transaction do 
            self.status = 'APPROVED'
            self.save!

            overlapping_pending_requests.each do |req|
                req.update!(status: 'DENIED')
            end
        end
    end

    def deny!
        self.status = "DENIED"
        self.save!
    end

    def pending? 
        self.status == "PENDING"
    end

    def overlapping_requests
        overlap = CatRentalRequest
            .where.not(id: id)
            .where(cat_id: cat_id)
            .where.not("start_date > :end_date OR end_date < :start_date", 
                start_date: self.start_date, end_date: self.end_date)
        return overlap
    end

    def overlapping_approved_requests
        overlapping_requests.where("status = 'APPROVED'")
    end

    def does_not_overlap_approved_request
        unless overlapping_approved_requests.length == 0
            errors[:base] <<
                "Overlapping request"
        end
    end

    def overlapping_pending_requests
        overlapping_requests.where("status = 'PENDING'")
    end
end

# prr = CatRentalRequest.find(2)
# prr.overlapping_approved_requests