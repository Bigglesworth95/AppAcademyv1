class CatsController < ApplicationController
    def index
        @cats = Cat.all
        render :index
    end

    def show
        @cat = Cat.find_by(id: params[:id])
        if @cat
            @requests = CatRentalRequest.find_by_sql(["SELECT * FROM cat_rental_requests WHERE cat_id = ?", @cat.id])
        else
        raise 'No such cat'
        end
    end

    def new
        @cat = Cat.new
        #above gives permission to view to access instance variable
        #how do we know params will have id in it? Answer in routes table. 
        #edit shows cats/:id/edit <- colon id tells us we have access to id
        render :new
    end

    def create
       @cat = Cat.new(cat_params)
       if @cat.save
        #show user new cat page
        redirect_to cat_url(@cat)
       else
        #show user the create page
        render :new
       end
    end
    def edit
        @cat = Cat.find_by(id: params[:id])
        render :edit
    end

    def update
        @cat = Cat.find_by(id: params[:id])
        if @cat.update_attributes(cat_params)
            redirect_to cat_url(@cat)
        else
            render :edit
        end
    end

    
    
    private
    def cat_params
        params.require(:cat).permit(:age, :birth_date, :color, :description, :name, :sex)
    end


end