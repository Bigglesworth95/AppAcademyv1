# == Schema Information
#
# Table name: shortened_urls
#
#  id           :bigint           not null, primary key
#  short_url    :string           not null
#  long_url     :string           not null
#  submitter_id :integer          not null
#  created_at   :datetime         not null
#  updated_at   :datetime         not null
#
class ShortenedUrl < ApplicationRecord
    validates :short_url, uniqueness: true
    #validates :submitter_id, presence: true

    belongs_to(
        :submitter, 
        primary_key: :id, 
        class_name: :User,
        foreign_key: :submitter_id
    )

    has_many(
        :visits, 
        class_name: :Visit, 
        primary_key: :id,
        foreign_key: :shortened_url_id
    )

    has_many(
        :visitors, 
        Proc.new { distinct },
        through: :visits, 
        source: :visitor
    )

    has_many(
        :tag_topics,
        through: :taggings,
        source: :tag_topic
    )

    has_many(
        :taggings,
        primary_key: :id,
        foreign_key: :shortened_url_id,
        class_name: :Tagging
    )

    def self.random_code
        random_code = SecureRandom.urlsafe_base64(16)
        while ShortenedUrl.exists?(short_url: random_code)
            random_code = SecureRandom.urlsafe_base64(16)
        end
        return random_code
    end

    def self.create_short_url(user, long_url)
        ShortenedUrl.create!(
            long_url: long_url,
            short_url: ShortenedUrl.random_code,
            submitter_id: user.id
        )
    end

    def num_clicks
        visits.count
    end

    def num_uniques
        visits.select('user_id').distinct.count
    end

    def num_recent_uniques
        visits
            .select('user_id')
            .where('created_at > ?', 10.minutes.ago)
            .distinct
            .count
    end

    def no_spamming
        last_minute = ShortenedUrl
            .where('created_at > ?', 1.minute.ago)
            .where(submitter_id: submitter_id)
            .length
        errors[:maximum] << 'of five short urls per minute'
    end

    def nonpremium_max
        return if User.find(self.submitter_id).premium

        number_of_urls = 
            ShortenedUrl
                .where(submitter_id: submitter_id)
                .length
        if number_of_urls >=5
            errors[:Only] << 'premium members can create more than 5 short urls'
        end
    end

    def self.prune(n)
        ShortenedUrl
            .joins(:submitter)
            .joins('LEFT JOIN visits ON visits.shortened_url_id = shortened_urls.id')
            .where("(shortened_urls.id IN (
                SELECT shortened_urls
                JOIN visits
                ON visits.shortened_url_id = shortened_urls.id
                GROUP BY shortened_urls.id
                HAVING MAX(visits.created_at < \'#{n.minute.ago}\'
                ) OR (
                visits.id IS NULL and shortened_urls.created_at < \'#{n.minute.ago}\'
                )) AND users.premium = \'f\'")
            .desroy_all

    end
end
