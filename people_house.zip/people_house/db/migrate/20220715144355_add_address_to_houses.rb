class AddAddressToHouses < ActiveRecord::Migration[7.0]
  def change
    add_column :houses, :address, :string, null: false
  end
end
