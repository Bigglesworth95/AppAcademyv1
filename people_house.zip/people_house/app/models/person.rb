# == Schema Information
#
# Table name: people
#
#  id         :bigint           not null, primary key
#  name       :string           not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#
class Person < ApplicationRecord
    validates :name, presence: true
    validates :house_id, presence: true

    belongs_to(
        :house, #or house? class or db?
        class_name: :House, 
        foreign_key: :house_id,
        primary_key: :id
    )
end
