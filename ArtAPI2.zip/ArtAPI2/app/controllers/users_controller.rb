class UsersController < ApplicationController
    def index
        render plain: "index here"
    end

    def create
        render json: params
    end
end