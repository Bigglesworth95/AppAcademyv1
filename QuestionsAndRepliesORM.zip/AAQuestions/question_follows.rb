require_relative 'questions_database'
require_relative 'users'
require_relative 'questions'
require_relative 'replies'

class QuestionFollow
    def self.followers_for_question_id(question_id)
        users_data = QuestionsDatabase.execute(<<-SQL, question_id: question_id)
            SELECT 
                users.*
            FROM
                users
            JOIN
                question_follows
            ON 
                users.id = question_follows.user_id 
            WHERE
                question_follows.question_id = :question_id
            SQL
        users_data.map {|user_data| User.new(user_data)}
    end

    def self.followed_questions_for_user_id(user_id)
        questions_data = QuestionsDatabase.execute(<<-SQL, user_id: user_id) #why did the color change
            SELECT 
                questions.*
            FROM 
                questions
            JOIN
                question_follows
            ON
                questions.id = question_follows.question_id
            WHERE
                question_follows.user_id = :user_id
            SQL
        questions_data.map {|question_data| Questions.new(question_data)}
    end

    def self.most_followed_questions(n)
        questions_data =QuestionsDatabase.execute(<<-SQL, n: n)
            SELECT
                questions.*
            FROM
                questions
            JOIN
                question_follows
            ON
                questions.id = question_follows.question_id
            GROUP BY
                question_id
            ORDER BY
                COUNT(*)
            LIMIT
                :n
            SQL
        questions_data.map {|question_data| Questions.new(question_data)}
    end
end