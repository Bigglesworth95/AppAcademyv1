require_relative "questions_database"
require_relative "questions"
require_relative "replies"
require_relative "question_follows"

#require_relative "model_base"

class User #< ModelBase
    attr_reader :id
    attr_accessor :fname, :lname
    def initialize (options = {})#what is this whole bracket nonsense
        @id, @fname, @lname = options.values_at('id', 'fname', 'lname')
    end
    def self.find_by_id(id)
        user_data = QuestionsDatabase.get_first_row(<<-SQL, id: id)
            SELECT 
                users.*
            FROM
                users
            WHERE
                users.id = :id
            SQL
        user_data.nil? ? nil : User.new(user_data)
    end

    def self.find_by_name(fname, lname)
        user_data = QuestionsDatabase.get_first_row(<<-SQL, fname: fname, lname: lname)
        SELECT
            users.*
        FROM 
            users
        WHERE
            users.fname = :fname
            AND 
            users.lname = :lname
        SQL
        user_data.nil? ? nil : User.new(user_data)
    end

    def followed_questions
        QuestionFollow.followed_questions_for_user_id(id)
    end

    def liked_questions
        QuestionLikes.liked_questions_for_user_id(@id)
    end

    def average_karma(id = @id)
        user_data = QuestionsDatabase.execute(<<-SQL, id: id)
        SELECT
            CAST((COUNT(question_likes.id))/(COUNT (DISTINCT questions.id)) AS FLOAT) AS avg_karma
        FROM
            questions
        JOIN
            question_likes
        ON
            questions.author_id = question_likes.user_id
        WHERE
            questions.author_id = :id
        SQL
        p  user_data
    end

    def save
        if @id == nil
            QuestionsDatabase.execute(<<-SQL, attrs)
                INSERT INTO
                    users(fname, lname)
                VALUES
                    (:fname, :lname)
            SQL
            @id = QuestionsDatabase.insert_last_row_id
        else
            QuestionsDatabase.execute(<<-SQL, attrs.merge({id: id}))
            UPDATE
                users
            SET
                fname = :fname, lname = :lname
            WHERE
                users.id = :id
            SQL
        end
        self
    end

end