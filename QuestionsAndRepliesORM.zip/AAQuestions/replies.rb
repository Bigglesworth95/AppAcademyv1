require_relative 'questions_database'
require_relative 'users'
require_relative 'questions'
require_relative "question_follows"

class Reply
    attr_reader :id
    attr_accessor :question_id, :parent_reply_id, :user_id, :body
    def save
        if @id == nil
            QuestionsDatabase.execute(<<-SQL, attrs)
                INSERT INTO
                    replies
                VALUES
                    @question_id = :question_id, @parent_reply_id = :parent_reply_id, @user_id = :user_id, @body = :body
                SQL
            @id = QuestionsDatabase.insert_last_row_id
        else
            QuestionsDatabase.execute(<<-SQL, arrts.merge({id: @id}))
                UPDATE
                    replies
                VALUES
                    (question_id = :question_id, parent_reply_id = :parent_reply_id, user_id = :user_id, body = :body)
                WHERE
                    replies.id = :id
            SQL
        end
        self
    end
    def initialize(options = {})
        @id, @question_id, @parent_reply_id, @user_id, @body = options.values_at(
            'id', 'question_id', 'parent_reply_id', 'user_id', 'body'
        )
    end

    def self.find_by_id(id)
        reply_data = QuestionsDatabase.get_first_row(<<-SQL, id: id)
            SELECT
                replies.*
            FROM
                replies
            WHERE
                replies.id = :id
            SQL
        reply_data.nil? ? nil : Reply.new(reply_data)
    end

  def self.find_by_parent_id(parent_id)
    replies_data = QuestionsDatabase.execute(<<-SQL, parent_reply_id: parent_id)
      SELECT
        replies.*
      FROM
        replies
      WHERE
        replies.parent_reply_id = :parent_reply_id
    SQL

    replies_data.map { |reply_data| Reply.new(reply_data) }
  end

    def self.find_by_question_id(question_id)
        replies_data = QuestionsDatabase.execute(<<-SQL, question_id: question_id)
            SELECT
                replies.*
            FROM
                replies
            WHERE
                replies.question_id = :question_id
            SQL
        replies_data.map {|reply_data| Reply.new(reply_data)}
    end

    def self.find_by_user_id(user_id)
        replies_data = QuestionsDatabase.execute(<<-SQL, user_id: user_id)
        SELECT
            replies.*
        FROM 
            replies
        WHERE
            replies.user_id = :user_id
        SQL
    replies_data.map {|reply_data| Reply.new(reply_data)}
    end
end