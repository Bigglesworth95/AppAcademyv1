DROP TABLE IF EXISTS question_tags;
DROP TABLE IF EXISTS question_follows;
DROP TABLE IF EXISTS question_likes;
DROP TABLE IF EXISTS replies;
DROP TABLE IF EXISTS questions;
DROP TABLE IF EXISTS tags;
DROP TABLE IF EXISTS users;

PRAGMA foreign_keys = ON;
CREATE TABLE users (
    id INTEGER PRIMARY KEY,
    fname VARCHAR(255), 
    lname VARCHAR(255)
    
);

INSERT INTO 
    users(fname, lname)
VALUES
    ("Dan", "Araujo"), ("Neil", "McNeil"), ("John", "Johnson");

CREATE TABLE questions (
    id INTEGER PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    body VARCHAR(255) NOT NULL,
    author_id INTEGER NOT NULL,
    FOREIGN KEY (author_id) REFERENCES users(id)
);

INSERT INTO 
    questions (title, body, author_id)
SELECT
    "Dan question", "Dan Dan Dan", users.id
FROM 
    users
WHERE
    users.fname = "Dan" AND users.lname = "Araujo";


INSERT INTO
    questions(title, body, author_id)
SELECT
    "Neil question", "Neil Neil Neil", users.id
FROM
    users
WHERE 
    users.fname = "Neil" AND users.lname = "McNeil";


INSERT INTO
    questions(title, body, author_id)
SELECT
    "John question", "John John John", users.id
FROM
    users
WHERE 
    users.fname = "John" AND users.lname = "Johnson";



CREATE TABLE question_follows (
    id INTEGER PRIMARY KEY,
    question_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    FOREIGN KEY (question_id) REFERENCES questions(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

INSERT INTO 
    question_follows(user_id, question_id)
VALUES
    ((SELECT id FROM users WHERE fname = "Dan" AND lname = "Araujo"),
    (SELECT id FROM questions WHERE title = "Dan question")),
    ((SELECT id FROM users WHERE fname = "Neil" AND lname = "McNeil"),
    (SELECT id FROM questions WHERE title = "Neil question"));


    -- repplies

CREATE TABLE replies (
    id INTEGER PRIMARY KEY,
    question_id INTEGER NOT NULL,
    parent_reply_id INTEGER,
    user_id INTEGER NOT NULL, 
    body_text TEXT NOT NULL, 

    FOREIGN KEY (question_id) REFERENCES questions(id),
    FOREIGN KEY (parent_reply_id) REFERENCES replies(id),
    FOREIGN KEY (user_id) REFERENCES users(id)  
);



INSERT INTO 
    replies(question_id, parent_reply_id, user_id, body_text)
VALUES 
    ((SELECT id FROM questions WHERE title = "Dan question"),
    NULL,
    (SELECT id FROM users WHERE fname = "Neil" AND lname = "McNeil"),
    "Hi Dan!");

INSERT INTO
    replies(question_id, parent_reply_id, user_id, body_text)
VALUES
    ((SELECT id FROM questions WHERE title = "Dan question"), 
    (SELECT id FROM replies WHERE body_text = "Hi Dan!"),
    (SELECT id FROm users WHERE fname = "John" AND lname = "Johnson"), 
    "Hi Neil!");

CREATE TABLE question_likes (
    id INTEGER PRIMARY KEY,
    question_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,

    FOREIGN KEY (question_id) REFERENCES questions(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

INSERT INTO 
    question_likes(question_id, user_id)
VALUES
    ((SELECT id FROM questions WHERE title = "Dan question"),
    (SELECT id FROM users WHERE fname = "Neil" AND lname = "McNeil"));

INSERT INTO question_likes(user_id, question_id) VALUES (1,1);
INSERT INTO question_likes (user_id, question_id) VALUES (1, 2);
