require_relative "questions_database"
require_relative "questions"
require_relative "users"
require_relative "replies"
require_relative "question_follows"
require_relative "questions_likes"
require 'byebug'


class Questions
    attr_reader :id
    attr_accessor :title, :body, :author_id
    def initialize (options={})
        @id, @title, @body, @author_id = options.values_at('id', 'title', 'body', 'author_id')
    end

    def self.find_by_id(id)
        user_data = QuestionsDatabase.get_first_row(<<-SQL, id: id)
            SELECT 
                questions.*
            FROM 
                questions
            WHERE
                questions.id = :id
        SQL
        Questions.new(user_data)
    end

    def self.find_by_title(title)
        user_data = QuestionsDatabase.get_first_row(<<-SQL, title: title)
            SELECT 
                questions.*
            FROM
                questions
            WHERE
                questions.title = :title
        SQL
        user_data.nil? ? nil : Questions.new(user_data)
    end

    def self.find_by_user_id(user_id)
        user_data = QuestionsDatabase.execute(<<-SQL, user_id: user_id)
        SELECT 
            questions.*
        FROM
            questions
        WHERE
            questions.author_id = :user_id
        SQL

        user_data.map { |data| Questions.new(data)}
    end

    def followers
        QuestionFollow.followers_for_question_id(@id)
    end

    def self.most_followed
        QuestionFollow.most_followed_questions(1)
    end

    def likers
        QuestionLikes.likers_for_question_id(@id)
    end

    def num_likes
        QuestionLikes.num_likes_for_question_id(@id)
    end

    def self.most_liked
        QuestionLikes.most_liked_questions(1)
    end

    def save
        if @id == nil 
            QuestionsDatabase.execute(<<-SQL, attrs)
                INSERT INTO 
                    questions(title, body, author_id)
                VALUES
                    (:title, :body, :author_id)
            SQL
            @id = QuestionsDatabase.insert_last_row_id
        else
            QuestionsDatabase.execute(<<-SQL, attrs.merge({id: id}))
                UPDATE
                    questions
                SET
                    title = :title, body = :body, author_id = :author_id
                WHERE
                    questions.id = :id
            SQL
        end
        self
    end
end

