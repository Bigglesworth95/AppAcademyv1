require_relative 'db_connection'
require 'active_support/inflector'
# NB: the attr_accessor we wrote in phase 0 is NOT used in the rest
# of this project. It was only a warm up.

class SQLObject
  def self.columns
    return @columns if @columns
    cols = DBConnection.execute2(<<-SQL)
    SELECT
      *
    FROM
      "#{table_name}"
    LIMIT
      0
    SQL
    cols = cols[0].map!(&:to_sym)
    @columns = cols
  end

  def self.finalize!

    self.columns.each do |col| #why self and not @?
      define_method(col) do 
        self.attributes[col]
      end

      define_method("#{col}=") do |value|
        self.attributes[col] = value
      end
    end
  end

  def self.table_name=(table_name)
    @table_name = table_name
  end

  def self.table_name
    @table_name || self.name.underscore.pluralize
  end

  def self.all
    objs = DBConnection.execute(<<-SQL)
      SELECT
        "#{self.table_name}".*
      FROM
        "#{self.table_name}"
    SQL
    parse_all(objs)
  end

  def self.parse_all(results)
    results.map {|result| self.new(result)}
  end

  def self.find(id) #why no 'self' in front of .table_name
    result = DBConnection.execute(<<-SQL, id) 
      SELECT 
        #{table_name}.*
      FROM
        #{table_name}
      WHERE
        id = ?
    SQL
    parse_all(result)[0]
  end

  def initialize(params = {})
    params.each do |attr_name, attr_val|
      attr_name = attr_name.to_sym
      raise "unknown attribute '#{attr_name}'" if !self.class.columns.include?(attr_name)
      self.send("#{attr_name}=", attr_val)
    end
  end

  def attributes
    return @attributes if @attributes
    @attributes = {}
  end

  def attribute_values
    self.class.columns.map {|attr| self.send(attr)}
  end

  def insert
    columns = self.class.columns.drop(1)
    col_names = columns.map(&:to_s).join(', ')
    vars = ['?']*(columns.length)
    vars = vars.join(', ')
    
    DBConnection.execute(<<-SQL, *attribute_values.drop(1))
      INSERT INTO
        #{self.class.table_name} (#{col_names})
      VALUES
        (#{vars})
      SQL
    self.id = DBConnection.last_insert_row_id
  end

  def update
    set = self.class.columns.map{|col| col = "#{col} = ?"}.join(', ')
    DBConnection.execute(<<-SQL, *attribute_values, id)
      UPDATE
        #{self.class.table_name}
      SET
        #{set}
      WHERE
        #{self.class.table_name}.id = ? 
      SQL
  end

  def save
    id.nil? ? insert : update
  end
end
