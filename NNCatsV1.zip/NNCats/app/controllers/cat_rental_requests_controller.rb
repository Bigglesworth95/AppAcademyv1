class CatRentalRequestsController < ApplicationController
    def new
        @cat_rental_request = CatRentalRequest.new
    end

    def create
        @cat_rental_request = CatRentalRequest.new(cat_rental_request_params)
        @cat_rental_request.status = overlaps?
        if @cat_rental_request.save
            redirect_to cat_url(Cat.find_by(id: @cat_rental_request.cat_id))
        else
            raise "Request failed"
        end
    end

    def show
        rental_request = CatRentalRequest.find(id: params[:id])
        if rental_request
            render json: rental_request
        else
            raise "No such request"
        end

    end


    private 
    def cat_rental_request_params
        params.require(:cat_rental_request).permit(:start_date, :end_date, :cat_id, :status)
    end

    def overlaps? 
        overlap = CatRentalRequest
            .where.not(id: params[:id])
            .where(cat_id: params[:cat_id])
            .where.not("start_date > :end_date OR end_date < :start_date", 
                start_date: params[:start_date], end_date: params[:end_date])
            .where("status = 'APPROVED'")
        
        if overlap.length > 0
            return "DENIED"
        else
            return "PENDING"
        end
    end

end