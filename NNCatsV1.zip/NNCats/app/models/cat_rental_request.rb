class CatRentalRequest < ApplicationRecord
    STATUS_STATES = %w(PENDING APPROVED DENIED).freeze
    validates :status, inclusion: STATUS_STATES
    belongs_to :cat
    validate :does_not_overlap_approved_request

    def overlapping_requests
        overlap = CatRentalRequest
            .where.not(id: id)
            .where(cat_id: cat_id)
            .where.not("start_date > :end_date OR end_date < :start_date", 
                start_date: self.start_date, end_date: self.end_date)
        return overlap
    end

    def overlapping_approved_requests
        overlapping_requests.where("status = 'APPROVED'")
    end

    def does_not_overlap_approved_request
        unless overlapping_approved_requests.length == 0
            errors[:base] <<
                "Overlapping request"
        end
    end
end

# prr = CatRentalRequest.find(2)
# prr.overlapping_approved_requests