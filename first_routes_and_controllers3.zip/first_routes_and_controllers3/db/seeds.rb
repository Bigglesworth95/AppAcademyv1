# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)
User.destroy_all
Artwork.destroy_all
ArtworkShare.destroy_all

dan = User.create!(username:'dan')
mike = User.create!(username: 'mike')
mona = Artwork.create!(title: 'Mona Lisa', image_url: 'mona.com', artist_id: dan.id)
sistine = Artwork.create!(title: 'Sistine Chapel', image_url: 'sistine.com', artist_id: mike.id)
ArtworkShare.create!(artwork_id: mona.id, viewer_id: mike.id)
ArtworkShare.create!(artwork_id: sistine.id, viewer_id: dan.id)
comment1 = Comment.create!(body: "great!", user_id: dan.id, artwork_id: mona.id)
comment2 = Comment.create!(body: "another great one!", user_id: mike.id, artwork_id: sistine.id)