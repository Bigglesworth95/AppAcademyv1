class Artwork < ApplicationRecord
    belongs_to(
        :artist,
        class_name: "User",
        foreign_key: :artist_id#,
        #primary_key: :id
    )

    has_many(
        :comments, 
        foreign_key: :artwork_id,
        dependent: :destroy
    )

    def self.artworks_for_user_id(user_id)
        join = <<-SQL
            FULL OUTER JOIN 
                artwork_shares
            ON
                artworks.id = artwork_shares.artwork_id
            SQL
        where = <<-SQL
            ((artworks.artist_id = :user_id) OR (artwork_shares.viewer_id = :user_id))
        SQL
        Artwork
            .joins(join)
            .where(where, user_id: user_id)
            .uniq
    end
end